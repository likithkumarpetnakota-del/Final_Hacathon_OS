# SyncLock

**Real Linux file locking, visualized.** SyncLock launches multiple OS processes that compete for one shared file. In *locked* mode they coordinate with the kernel's `fcntl.flock()`; in *unlocked* mode they don't, and updates get silently lost. A live dashboard shows exactly what the OS did.

```
Browser ──SSE──► FastAPI ──► Lock Manager ──► fcntl.flock() ──► data/shared.json
                    ▲                                ▲
                    └── events ◄── N worker processes (multiprocessing, spawn)
```

Nothing on the dashboard is scripted. Each worker process calls `flock()`, and emits an event *after* the syscall returns. The server forwards those events to the browser over Server-Sent Events. The "Kernel lock table" panel reads `/proc/locks` directly, so you can show the kernel's own record of who holds or waits for the lock.

## Run it (Ubuntu)

```bash
sudo apt install -y python3-venv   # only if venv is missing
./run.sh                           # creates .venv, installs deps, serves on :8000
```

Open <http://localhost:8000>. Use a different port with `PORT=9000 ./run.sh`.

**No browser? No problem.** The same engine runs in the terminal:

```bash
python3 -m synclock.cli              # locked, then unlocked, then a comparison table
python3 -m synclock.cli --verbose    # also print every event
```

Typical result (5 writers × 6 ops, 120 ms critical section):

| | Locked | Unlocked |
|---|---|---|
| Expected updates | 30 | 30 |
| Final counter in file | **30** | **6** |
| Lost updates | 0 | 24 |
| Max writers inside critical section | **1** | 5 |

## 90-second demo script

1. Open the dashboard. Point at the pipeline in the header: *Browser → FastAPI → Lock Manager → `fcntl.flock()` → Shared file.*
2. Click **Compare locked vs unlocked**.
3. **Locked run:** green bars (LOCK_EX) never overlap. Amber bars are processes the kernel made wait. The version climbs v1 → v30 with no gaps, and the kernel table shows one `EXCLUSIVE HELD` row plus `WAITING` rows.
4. **Unlocked run:** red bars stack on top of each other, red bands mark ≥2 writers overlapping, `LOST UPDATE` events flood the log, and the counter ends far below 30.
5. Close with the comparison table: *same code, same hardware, the only difference is `flock()`.*

## Questions judges may ask

**Is this a real implementation or a simulation?**
Real. `synclock/lockmanager.py` calls `fcntl.flock()` on a real file descriptor. Workers are real processes (`multiprocessing`, `spawn`). The dashboard visualizes events those processes emit, plus `/proc/locks` from the kernel.

**Why did two processes read the same version without locking?**
Read-modify-write is not atomic. Both read `v7`, both compute `v8`, the second write overwrites the first. That's a lost update, and it's the bug locking prevents.

**`flock` vs `fcntl.lockf` (POSIX locks)?**
`flock` locks the whole file and belongs to the open file description (inherited across `fork`, released when the last descriptor closes). `fcntl.lockf` gives byte-range locks owned by the process. SyncLock uses `flock` for whole-file mutual exclusion. Byte-range locks are the natural extension for locking records instead of the whole file.

**Are the locks mandatory?**
No, they're **advisory**: they only stop processes that also call `flock()`. A process that ignores the protocol can still write. All SyncLock workers go through the same lock manager, which is exactly the contract advisory locking assumes.

**What about deadlock and fairness?**
There is a single lock, so no lock-ordering deadlock is possible. `flock` does not guarantee FIFO ordering; the kernel picks the next waiter, so starvation is theoretically possible under heavy contention.

**What does `LOCK_NB` do in your code?**
Each acquire first tries `LOCK_EX | LOCK_NB`. If the kernel answers `EWOULDBLOCK`, the lock is genuinely busy: we report `BLOCKED`, then block in a normal `flock()` until granted. That is how the dashboard shows real conflicts.

**What is `LOCK_SH` for?**
Reader processes take shared locks: many readers can hold the file together, but a writer's `LOCK_EX` waits for them all and blocks new ones.

**Does it work over NFS?**
Linux emulates `flock` over NFS with byte-range locks, but behaviour depends on server and mount options. This demo targets a local filesystem.

## Honest notes

- In *unlocked* mode each writer re-reads the file just before writing to emit a `LOST_UPDATE` event. That is instrumentation only; it protects nothing. The authoritative evidence is the final counter in the file.
- Event timestamps come from `time.time()` on one machine. `RELEASED` is stamped *before* `LOCK_UN` so it can never appear to occur after the next owner's `ACQUIRED`; this is what makes the "max writers inside critical section" number trustworthy.
- If `/proc/locks` isn't readable (some containers), the kernel panel shows no locks; everything else still works.

## Layout

```
synclock/
├── run.sh                    start the server
├── requirements.txt          fastapi, uvicorn
├── data/shared.json          the shared file (created/reset by the simulator)
└── synclock/
    ├── lockmanager.py        flock() wrapper + /proc/locks reader
    ├── worker.py             one OS process: locked or unlocked read-modify-write
    ├── simulator.py          spawns workers, collects events, builds the summary
    ├── server.py             FastAPI: /api/run, /api/events (SSE), /api/state, ...
    ├── cli.py                terminal demo and self-test
    └── static/index.html     the dashboard (no external dependencies)
```

## API

| Endpoint | Purpose |
|---|---|
| `POST /api/run` | `{mode, writers, readers, ops, hold_ms}` start a simulation |
| `GET /api/events` | SSE stream of every worker event |
| `GET /api/state` | file content + kernel lock table |
| `GET /api/results` | summaries of the last locked/unlocked runs |
| `POST /api/reset` | reset the shared file |

## Ideas if you have time left

- Byte-range locking with `fcntl.lockf` (lock records, not the whole file).
- A lock timeout using `LOCK_NB` polling, and a "stuck holder" scenario.
- A writer-starvation experiment with many readers.
