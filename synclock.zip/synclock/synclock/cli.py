"""Terminal-only demo / self-test (no browser needed).

    python -m synclock.cli                # run locked, then unlocked, print a comparison
    python -m synclock.cli --verbose      # also print every event
    python -m synclock.cli --writers 8 --ops 10 --hold-ms 80

Exit status is 0 only if the LOCKED run preserved every update and never had
two writers inside the critical section at once.
"""
from __future__ import annotations

import argparse
import sys

from .simulator import run_simulation


def main() -> int:
    ap = argparse.ArgumentParser(description="SyncLock terminal demo")
    ap.add_argument("--writers", type=int, default=5)
    ap.add_argument("--readers", type=int, default=2)
    ap.add_argument("--ops", type=int, default=6)
    ap.add_argument("--hold-ms", type=int, default=120)
    ap.add_argument("--verbose", action="store_true")
    a = ap.parse_args()

    def make_emit(mode):
        t0 = {}

        def emit(ev):
            if not a.verbose or ev["type"] in ("RUN_START", "RUN_DONE"):
                return
            t0.setdefault("t", ev["t"])
            print(f"  [{mode:8}] +{ev['t'] - t0['t']:6.3f}s {ev['worker']:>3} pid {ev['pid']:<7} "
                  f"{ev['type']:<12} { {k: v for k, v in ev.items() if k in ('wait_ms', 'old', 'new', 'seen', 'actual')} or ''}")
        return emit

    results = {}
    for mode in ("locked", "unlocked"):
        print(f"\n== {mode.upper()} run: {a.writers} writers x {a.ops} ops, "
              f"{a.readers} readers, {a.hold_ms} ms critical section ==")
        results[mode] = run_simulation(mode, a.writers, a.readers, a.ops, a.hold_ms, make_emit(mode))

    rows = [("Expected updates", "expected"), ("Final counter in file", "final_counter"),
            ("Lost updates", "lost_updates"), ("Max writers inside critical section", "max_concurrent_writers"),
            ("Contended lock requests", "contended"), ("Avg lock wait (ms)", "avg_wait_ms"),
            ("Duration (s)", "duration_s"), ("Corrupt reads", "corrupt_reads")]
    print(f"\n{'':40}{'LOCKED':>12}{'UNLOCKED':>12}")
    for label, key in rows:
        print(f"{label:40}{results['locked'][key]:>12}{results['unlocked'][key]:>12}")
    print(f"{'Verdict':40}{'OK' if results['locked']['ok'] else 'DATA LOST':>12}"
          f"{'OK' if results['unlocked']['ok'] else 'DATA LOST':>12}")

    good = results["locked"]["ok"] and results["locked"]["max_concurrent_writers"] == 1
    if not good:
        print("\nSELF-TEST FAILED: the locked run lost updates or overlapped.")
    elif results["unlocked"]["ok"]:
        print("\nNote: the unlocked run got lucky. Raise --writers or --hold-ms for more contention.")
    else:
        print("\nSELF-TEST PASSED: flock() preserved every update; without it updates were lost.")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
