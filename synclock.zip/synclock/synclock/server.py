"""FastAPI backend: browser -> FastAPI -> lock manager -> fcntl.flock() -> shared file."""
from __future__ import annotations

import asyncio
import json
import os
import threading
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from pydantic import BaseModel, Field

from .lockmanager import kernel_locks
from .simulator import SHARED_FILE, reset_file, run_simulation

STATIC = Path(__file__).resolve().parent / "static"
BOOT = os.urandom(4).hex()  # lets the browser detect a server restart


class Hub:
    """Fans events from worker threads out to every connected browser (SSE)."""

    def __init__(self):
        self.lock = threading.Lock()
        self.subs: set[asyncio.Queue] = set()
        self.history: list[dict] = []   # events of the current/last run, for late joiners
        self.results: dict[str, dict] = {}
        self.seq = 0
        self.loop: asyncio.AbstractEventLoop | None = None
        self.running = False

    def publish(self, ev: dict) -> None:
        with self.lock:
            ev = {**ev, "seq": self.seq, "boot": BOOT}
            self.seq += 1
            self.history.append(ev)
            if ev["type"] == "RUN_DONE":
                self.results[ev["summary"]["mode"]] = ev["summary"]
            subs = list(self.subs)
        if self.loop:
            for q in subs:
                self.loop.call_soon_threadsafe(q.put_nowait, ev)

    def subscribe(self):
        q: asyncio.Queue = asyncio.Queue()
        with self.lock:
            self.subs.add(q)
            snapshot = list(self.history)
        return q, snapshot

    def unsubscribe(self, q):
        with self.lock:
            self.subs.discard(q)

    def clear_history(self):
        with self.lock:
            self.history = []


hub = Hub()


@asynccontextmanager
async def lifespan(app: FastAPI):
    hub.loop = asyncio.get_running_loop()
    if not SHARED_FILE.exists():
        reset_file()
    yield


app = FastAPI(title="SyncLock", lifespan=lifespan)


class RunRequest(BaseModel):
    mode: Literal["locked", "unlocked"] = "locked"
    writers: int = Field(5, ge=1, le=12)
    readers: int = Field(2, ge=0, le=6)
    ops: int = Field(6, ge=1, le=20)
    hold_ms: int = Field(120, ge=0, le=1000)


@app.get("/")
async def index():
    return FileResponse(STATIC / "index.html")


@app.post("/api/run")
async def start_run(req: RunRequest):
    if hub.running:
        raise HTTPException(status_code=409, detail="A simulation is already running.")
    hub.running = True
    hub.clear_history()

    def work():
        try:
            run_simulation(req.mode, req.writers, req.readers, req.ops, req.hold_ms,
                           emit=hub.publish)
        except Exception as exc:  # surface failures in the dashboard
            hub.publish({"type": "RUN_ERROR", "t": 0, "role": "system", "error": str(exc)})
        finally:
            hub.running = False

    threading.Thread(target=work, daemon=True).start()
    return {"started": True, "mode": req.mode}


@app.get("/api/state")
async def state():
    try:
        content = json.loads(SHARED_FILE.read_text())
        log = content.pop("log", [])
        content["log_length"] = len(log)
    except (OSError, ValueError):
        content = None
    return {
        "running": hub.running,
        "file": str(SHARED_FILE),
        "content": content,
        "kernel_locks": kernel_locks(str(SHARED_FILE)),
    }


@app.get("/api/results")
async def results():
    return hub.results


@app.post("/api/reset")
async def reset():
    if hub.running:
        raise HTTPException(status_code=409, detail="Cannot reset while a simulation is running.")
    reset_file()
    hub.results.clear()
    hub.clear_history()
    return {"reset": True}


@app.get("/api/events")
async def events(request: Request):
    q, snapshot = hub.subscribe()

    async def stream():
        try:
            for ev in snapshot:
                yield f"data: {json.dumps(ev)}\n\n"
            while True:
                if await request.is_disconnected():
                    break
                try:
                    ev = await asyncio.wait_for(q.get(), timeout=15)
                except asyncio.TimeoutError:
                    yield ": keep-alive\n\n"
                    continue
                yield f"data: {json.dumps(ev)}\n\n"
        finally:
            hub.unsubscribe(q)

    return StreamingResponse(
        stream(), media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("synclock.server:app", host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
