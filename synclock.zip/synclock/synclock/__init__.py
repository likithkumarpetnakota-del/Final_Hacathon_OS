"""SyncLock: real Linux file locking (fcntl.flock) with a live concurrency dashboard."""
