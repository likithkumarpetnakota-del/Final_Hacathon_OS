"""One worker = one real OS process hammering the shared file.

Each worker does read-modify-write cycles on data/shared.json:

    state = read();  state.version += 1;  state.counter += 1;  write(state)

With locking, the cycle sits inside flock(LOCK_EX), so no update can be lost.
Without locking, two processes read the same version and the later write wipes
out the earlier one: a classic lost update.

Events are timestamped around the real syscalls so the dashboard shows what the
OS actually did. RELEASED is stamped *before* LOCK_UN so that it can never appear
to happen after the next owner's ACQUIRED.
"""
from __future__ import annotations

import json
import os
import random
import time

from .lockmanager import LockedFile

EMPTY = {"version": 0, "counter": 0, "log": []}


def _load(lf: LockedFile):
    raw = lf.read_raw()
    try:
        return json.loads(raw.decode("utf-8")), False
    except (ValueError, UnicodeDecodeError):
        return dict(EMPTY, log=[]), True  # empty / half-written file (torn read)


def run_worker(name, role, ops, locked, hold_ms, path, q, barrier):
    pid = os.getpid()
    rng = random.Random(pid ^ int(time.time() * 1000))
    lf = LockedFile(path)

    def emit(type_, t=None, **kw):
        q.put({"t": t if t is not None else time.time(), "worker": name,
               "pid": pid, "role": role, "type": type_, **kw})

    def work(scale=1.0):
        # Simulates real work done inside the critical section.
        time.sleep(max(0.0, hold_ms * scale * rng.uniform(0.7, 1.3)) / 1000.0)

    try:
        barrier.wait(timeout=30)  # start every process at the same instant
    except Exception:
        pass

    for i in range(ops):
        op = i + 1
        emit("REQUEST", op=op)

        if role == "writer" and locked:
            acq = lf.acquire(True, on_contended=lambda: emit("BLOCKED", op=op))
            emit("ACQUIRED", op=op, shared=False,
                 wait_ms=round(acq.wait_ms, 2), contended=acq.contended)
            try:
                state, corrupt = _load(lf)
                if corrupt:
                    emit("CORRUPT_READ", op=op)
                old = state["version"]
                work()
                new = {"version": old + 1, "counter": state["counter"] + 1,
                       "log": state["log"] + [f"{name}#{op}"]}
                lf.write_raw(json.dumps(new).encode())
                emit("WRITE", op=op, old=old, new=old + 1, counter=new["counter"])
            finally:
                t_rel = time.time()
                lf.release()
                emit("RELEASED", t=t_rel, op=op)

        elif role == "writer":  # unlocked: same cycle, no flock()
            emit("ENTER", op=op, shared=False)
            state, corrupt = _load(lf)
            if corrupt:
                emit("CORRUPT_READ", op=op)
            old = state["version"]
            work()
            # Instrumentation only (protects nothing): did someone write meanwhile?
            cur, _ = _load(lf)
            if cur["version"] != old:
                emit("LOST_UPDATE", op=op, seen=old, actual=cur["version"])
            new = {"version": old + 1, "counter": state["counter"] + 1,
                   "log": state["log"] + [f"{name}#{op}"]}
            lf.write_raw(json.dumps(new).encode())
            emit("WRITE", op=op, old=old, new=old + 1, counter=new["counter"])
            emit("EXIT", op=op)

        elif locked:  # shared (reader) lock
            acq = lf.acquire(False, on_contended=lambda: emit("BLOCKED", op=op))
            emit("ACQUIRED", op=op, shared=True,
                 wait_ms=round(acq.wait_ms, 2), contended=acq.contended)
            try:
                state, corrupt = _load(lf)
                emit("CORRUPT_READ" if corrupt else "READ", op=op, version=state["version"])
                work(0.5)
            finally:
                t_rel = time.time()
                lf.release()
                emit("RELEASED", t=t_rel, op=op)

        else:  # unlocked reader
            emit("ENTER", op=op, shared=True)
            state, corrupt = _load(lf)
            emit("CORRUPT_READ" if corrupt else "READ", op=op, version=state["version"])
            work(0.5)
            emit("EXIT", op=op)

        time.sleep(rng.uniform(0, 0.03))

    emit("DONE")
    lf.close()
