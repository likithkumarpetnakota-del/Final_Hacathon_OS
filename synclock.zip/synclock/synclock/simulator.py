"""Spawns real OS processes that compete for one shared file and summarises the outcome."""
from __future__ import annotations

import json
import multiprocessing as mp
import queue
import time
from pathlib import Path
from typing import Callable

from .worker import run_worker

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
SHARED_FILE = DATA_DIR / "shared.json"
INITIAL_STATE = {"version": 0, "counter": 0, "log": []}


def reset_file(path: Path = SHARED_FILE) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:  # truncates in place: same inode
        json.dump(INITIAL_STATE, f)


def _max_concurrent(spans: list[tuple[float, float]]) -> int:
    pts = []
    for s, e in spans:
        pts.append((s, 1))
        pts.append((e, -1))
    pts.sort(key=lambda p: (p[0], p[1]))  # at equal times, ends sort before starts
    cur = best = 0
    for _, d in pts:
        cur += d
        best = max(best, cur)
    return best


def run_simulation(
    mode: str,
    writers: int,
    readers: int,
    ops: int,
    hold_ms: int,
    emit: Callable[[dict], None],
    path: Path = SHARED_FILE,
) -> dict:
    """Run one simulation. `emit` receives every event dict as it happens."""
    locked = mode == "locked"
    ctx = mp.get_context("spawn")
    reset_file(path)

    names = [(f"W{i + 1}", "writer") for i in range(writers)] + \
            [(f"R{i + 1}", "reader") for i in range(readers)]
    expected = writers * ops

    emit({"type": "RUN_START", "t": time.time(), "mode": mode, "expected": expected,
          "writers": writers, "readers": readers, "ops": ops, "hold_ms": hold_ms,
          "workers": [{"name": n, "role": r} for n, r in names]})

    q = ctx.Queue()
    barrier = ctx.Barrier(len(names))
    procs = [
        ctx.Process(target=run_worker, name=n,
                    args=(n, r, ops, locked, hold_ms, str(path), q, barrier))
        for n, r in names
    ]
    for p in procs:
        p.start()

    acquisitions = contended = lost_detected = corrupt = 0
    waits: list[float] = []
    open_start: dict[str, float] = {}
    spans: list[tuple[float, float]] = []
    t_min, t_max = float("inf"), 0.0

    def handle(ev: dict) -> None:
        nonlocal acquisitions, contended, lost_detected, corrupt, t_min, t_max
        t_min, t_max = min(t_min, ev["t"]), max(t_max, ev["t"])
        kind = ev["type"]
        if kind == "ACQUIRED":
            acquisitions += 1
            waits.append(ev.get("wait_ms", 0.0))
        elif kind == "BLOCKED":
            contended += 1
        elif kind == "LOST_UPDATE":
            lost_detected += 1
        elif kind == "CORRUPT_READ":
            corrupt += 1
        if ev["role"] == "writer":
            if kind in ("ACQUIRED", "ENTER"):
                open_start[ev["worker"]] = ev["t"]
            elif kind in ("RELEASED", "EXIT") and ev["worker"] in open_start:
                spans.append((open_start.pop(ev["worker"]), ev["t"]))
        emit(ev)

    def pull(timeout: float):
        try:
            return q.get(timeout=timeout)
        except queue.Empty:
            return None

    # Drain while the workers run (joining first could deadlock on a full pipe).
    while True:
        ev = pull(0.05)
        if ev is not None:
            handle(ev)
            continue
        if not any(p.is_alive() for p in procs):
            break
    while (ev := pull(0.2)) is not None:
        handle(ev)
    for p in procs:
        p.join()

    try:
        final = json.loads(Path(path).read_text())
    except ValueError:
        final = {"version": -1, "counter": -1}

    lost = expected - final["counter"]
    summary = {
        "mode": mode, "writers": writers, "readers": readers, "ops": ops, "hold_ms": hold_ms,
        "expected": expected,
        "final_counter": final["counter"], "final_version": final["version"],
        "lost_updates": lost, "lost_detected": lost_detected, "corrupt_reads": corrupt,
        "acquisitions": acquisitions, "contended": contended,
        "avg_wait_ms": round(sum(waits) / len(waits), 1) if waits else 0.0,
        "max_wait_ms": round(max(waits), 1) if waits else 0.0,
        "max_concurrent_writers": _max_concurrent(spans),
        "duration_s": round(t_max - t_min, 2) if t_max else 0.0,
        "ok": lost == 0 and corrupt == 0,
    }
    emit({"type": "RUN_DONE", "t": t_max or time.time(), "role": "system", "summary": summary})
    return summary
