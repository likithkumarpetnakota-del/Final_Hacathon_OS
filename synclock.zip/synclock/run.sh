#!/usr/bin/env bash
# Start the SyncLock dashboard on Ubuntu:  ./run.sh   ->  http://localhost:8000
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -d .venv ]; then
  python3 -m venv .venv || { echo "Install venv support first:  sudo apt install -y python3-venv"; exit 1; }
fi
# shellcheck disable=SC1091
. .venv/bin/activate
pip install -q -r requirements.txt

echo "SyncLock running at http://localhost:${PORT:-8000}"
exec uvicorn synclock.server:app --host 0.0.0.0 --port "${PORT:-8000}"
